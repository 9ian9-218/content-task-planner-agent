"""Reproducible CLI; all result files come from actual executions."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import platform
import sqlite3
import sys
from urllib.parse import urlsplit, urlunsplit

from .agent import Planner, empty_result
from .model import LiveModel, MockModel
from .tools import ROOT, fingerprint


def load_environment(path):
    """Read only project variables, without executing shell or expanding values."""
    if not path.is_file():
        return
    allowed = {"MODEL_API_KEY", "MODEL_BASE_URL", "MODEL_NAME"}
    for line in path.read_text(encoding="utf-8").splitlines():
        key, separator, value = line.strip().partition("=")
        if separator and key in allowed and key not in os.environ:
            os.environ[key] = value.strip().strip("\"'")


def export_result(result, original_input, destination, manifest):
    directory = Path(destination)
    directory.mkdir(parents=True, exist_ok=True)
    for name, value in [("input.json", original_input), ("manifest.json", manifest), ("output.json", result)]:
        (directory / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    trace = result.get("trace", [])
    exported_trace = trace or [{"event_type": "terminal_without_tool", "action_source": "runtime", "tool": None,
                               "status": result["status"], "reason_code": result.get("reason_code"),
                               "missing_fields": result.get("missing_fields", []), "note": "本次未执行业务工具，该事件是程序终态记录。"}]
    (directory / "trace.jsonl").write_text("".join(json.dumps(event, ensure_ascii=False) + "\n" for event in exported_trace), encoding="utf-8")
    (directory / "decisions.jsonl").write_text("".join(json.dumps(event, ensure_ascii=False) + "\n" for event in result.get("decisions", [])), encoding="utf-8")
    lines = ["# 实际执行 Trace", "", f"模式：{result['model_mode']}；状态：{result['status']}；缓存：{result.get('cached', False)}", "",
             "| 步骤 | 动作来源及已观察步骤 | 工具和参数 | 返回摘要 | 实际后续执行或终止 | 公开依据 |", "| --- | --- | --- | --- | --- | --- |"]
    for index, event in enumerate(trace):
        following = trace[index + 1]["tool"] if index + 1 < len(trace) else f"结束：{result.get('reason_code') or result['status']}"
        observed = event["result"]
        summary = {"ok": observed["ok"], "error_code": observed["error_code"], "data": observed["data"]}
        cells = [str(index + 1), event["action_source"] + f" / 已观察 {event.get('observed_after_step')}", event["tool"] + " " + json.dumps(event["parameters"], ensure_ascii=False),
                 json.dumps(summary, ensure_ascii=False), following, event["decision_summary"]]
        lines.append("| " + " | ".join(cell.replace("|", "\\|").replace("\n", " ") for cell in cells) + " |")
    lines += ["", f"终止原因：{result.get('reason_code') or result['status']}。{result.get('summary', '')}"]
    (directory / "trace.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    if result.get("saved_plan"):
        plan = result["saved_plan"]
        content = f"# {plan['goal']}\n\n{plan['outline']}\n\n## 脚本草稿\n\n{plan['script']['text']}\n\n素材：{', '.join(plan['source_ids'])}\n\n模拟费用：{plan['cost_units']}\n\n保存回执：{plan['plan_id']}\n\n仅表示方案已保存，活动未执行。\n"
        (directory / "plan.md").write_text(content, encoding="utf-8")
    elif (directory / "plan.md").exists():
        (directory / "plan.md").unlink()


def main(argv=None):
    parser = argparse.ArgumentParser(description="内容任务规划 Agent；业务工具为合成模拟。")
    commands = parser.add_subparsers(dest="command", required=True)
    run = commands.add_parser("run")
    run.add_argument("--input", required=True)
    run.add_argument("--mode", choices=["mock", "live"], default="mock")
    run.add_argument("--scenario")
    run.add_argument("--as-of")
    run.add_argument("--db", default=".local/state.sqlite3")
    run.add_argument("--output-dir")
    run.add_argument("--max-steps", type=int, default=12)
    run.add_argument("--max-tool-calls", type=int, default=12)
    run.add_argument("--timeout", type=float, default=180)
    run.add_argument("--env-file", default=".env.local")
    run.add_argument("--resume", action="store_true")
    args = parser.parse_args(argv)
    if args.output_dir:
        targets = [Path(args.output_dir, name).resolve() for name in
                   ["input.json", "output.json", "manifest.json", "trace.jsonl", "decisions.jsonl", "trace.md", "plan.md"]]
        protected = [Path(value).resolve() for value in [args.input, args.db, args.env_file, args.scenario] if value]
        protected += [Path(str(Path(args.db).resolve()) + suffix) for suffix in ["-journal", "-wal", "-shm"]]
        collisions = any(target == source or (target.exists() and source.exists() and target.samefile(source))
                         for target in targets for source in protected)
        if collisions:
            print(json.dumps(empty_result("invalid_request", "INVALID_CONFIGURATION", args.mode,
                                          summary="导出文件与输入、配置或数据库路径冲突；尚未执行工具，也不会写入该输出目录。"), ensure_ascii=False))
            return 2
    model = MockModel() if args.mode == "mock" else LiveModel()
    original_input, scenario = None, {}
    try:
        load_environment(Path(args.env_file))
        model = MockModel() if args.mode == "mock" else LiveModel()
        original_input = json.loads(Path(args.input).read_text(encoding="utf-8"))
        scenario = json.loads(Path(args.scenario).read_text(encoding="utf-8")) if args.scenario else {}
    except (OSError, ValueError):
        result = empty_result("invalid_request", "INVALID_INPUT", args.mode, summary="输入或配置文件无法读取，或不是有效 JSON。")
    else:
        planner = None
        try:
            if not isinstance(scenario, dict):
                raise ValueError("scenario must be a JSON object")
            planner = Planner(args.db, as_of=args.as_of, scenario=scenario, max_decisions=args.max_steps,
                              max_tool_calls=args.max_tool_calls, wall_timeout_seconds=args.timeout)
            result = planner.run(original_input, model=model, resume=args.resume)
        except (sqlite3.Error, OSError):
            result = empty_result("incomplete", "PERSISTENCE_FAILED", args.mode, original_input, "本地状态无法保存，不能宣称方案已保存。")
        except (ValueError, TypeError, KeyError):
            result = empty_result("invalid_request", "INVALID_CONFIGURATION", args.mode, original_input, "运行配置或合成费用/耗时表无效。")
        finally:
            if planner:
                planner.close()
    manifest = {"executed_at": datetime.now(timezone.utc).isoformat(), "command": [sys.executable, "-m", "content_planner"] + (argv if argv is not None else sys.argv[1:]),
                "mode": args.mode, "action_source": model.action_source, "python": platform.python_version(),
                "business_as_of": result.get("as_of"), "scenario": scenario, "state_database": str(args.db),
                "source_sha256": fingerprint({path.relative_to(ROOT).as_posix(): path.read_text(encoding="utf-8") for path in sorted((ROOT / "src").rglob("*.py"))})}
    endpoint = urlsplit(getattr(model, "base_url", ""))
    manifest.update(model_name=getattr(model, "model", "deterministic_mock"),
                    model_endpoint=urlunsplit((endpoint.scheme, endpoint.netloc.rsplit("@", 1)[-1], endpoint.path, "", "")),
                    model_requests_sent=result.get("model_requests_sent", 0), actual_result_mode=result["model_mode"],
                    data_versions=result.get("data_versions"), prompt_sha256=result.get("prompt_sha256"))
    if args.output_dir:
        try:
            export_result(result, original_input, args.output_dir, manifest)
        except OSError:
            result["export_errors"] = ["EXPORT_FAILED"]
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 4 if result.get("export_errors") else (0 if result["status"] == "completed" else (2 if result["status"] in ["needs_input", "invalid_request"] else 3))


if __name__ == "__main__":
    raise SystemExit(main())
