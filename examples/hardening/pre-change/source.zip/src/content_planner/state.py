import json
from pathlib import Path
import sqlite3


class Store:
    def __init__(self, path):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(path, timeout=5)
        self.connection.executescript("""
            CREATE TABLE IF NOT EXISTS requests (
                request_id TEXT PRIMARY KEY, fingerprint TEXT NOT NULL, snapshot TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS operations (
                operation_id TEXT PRIMARY KEY, request_id TEXT NOT NULL, payload TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS plans (
                plan_id TEXT PRIMARY KEY, request_id TEXT UNIQUE NOT NULL, payload TEXT NOT NULL);
        """)

    def get_request(self, request_id):
        row = self.connection.execute("SELECT snapshot FROM requests WHERE request_id=?", (request_id,)).fetchone()
        return json.loads(row[0]) if row else None

    def claim(self, context, resume=False):
        with self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            existing = self.get_request(context["request_id"])
            if existing:
                if not resume or existing["status"] == "running" or existing["input_fingerprint"] != context["input_fingerprint"]:
                    return False
                self.connection.execute("UPDATE requests SET snapshot=? WHERE request_id=?",
                                        (json.dumps(context, ensure_ascii=False), context["request_id"]))
            else:
                self.connection.execute("INSERT INTO requests VALUES (?, ?, ?)",
                                        (context["request_id"], context["input_fingerprint"], json.dumps(context, ensure_ascii=False)))
        return True

    def persist(self, context, plan=None):
        with self.connection:
            self.connection.execute(
                "INSERT INTO requests VALUES (?, ?, ?) ON CONFLICT(request_id) DO UPDATE SET snapshot=excluded.snapshot",
                (context["request_id"], context["input_fingerprint"], json.dumps(context, ensure_ascii=False)))
            for operation in context["operations"]:
                self.connection.execute("INSERT OR IGNORE INTO operations VALUES (?, ?, ?)",
                                        (operation["operation_id"], context["request_id"], json.dumps(operation, ensure_ascii=False)))
            if plan:
                self.connection.execute("INSERT INTO plans VALUES (?, ?, ?)",
                                        (plan["plan_id"], context["request_id"], json.dumps(plan, ensure_ascii=False)))

    def get_plan(self, plan_id):
        row = self.connection.execute("SELECT payload FROM plans WHERE plan_id=?", (plan_id,)).fetchone()
        return json.loads(row[0]) if row else None

    def list_plans(self):
        return [json.loads(row[0]) for row in self.connection.execute("SELECT payload FROM plans ORDER BY plan_id")]

    def close(self):
        self.connection.close()
